from conversion import decimalToBinaryConversion,binaryToDecimalConversion
import adder
import gates



choice = "yes"

while choice == "yes":
    try:
        a = int(input("Enter the First Value: "))
        b = int(input("Enter the Second Value: "))

    except:
        print("!!! INVALID ENTRY!!!!")
        print()
        print("Please Enter Correct input")
        continue

    while a<0 and b<0 or (a+b>255):
        try:
            print("!!! SORRY THE VALUE IS TOO LAGRE TO HOLD!!!")
            print()
            print("Enter the number between 0 and 255")

            a = int(input("Enter the First Number: "))
            b = int(input("Enter the Second Value: "))

        except:
            print("!!!! FORMAT IS NOT CORRECT!!!!")
            print()
            continue

    binary_Value_Of_a = decimalToBinaryConversion(a)
    binary_Value_Of_b = decimalToBinaryConversion(b)
    print()
    print("Binary value Of ", a, "= ",binary_Value_Of_a)
    print("Binary value Of ", b, "= ",binary_Value_Of_b)

    #Converting the binary value number a and b into list
    list_Of_a = list(binary_Value_Of_a)
    list_Of_b = list(binary_Value_Of_b)
    reverse_List_Of_a = list(reversed(list_Of_a))
    reverse_List_Of_b = list(reversed(list_Of_b))

    # Computing the sum of binary numbers present in list by calling function from Adder.py module
    reverse_sumList = adder.adder(reverse_List_Of_a,reverse_List_Of_b)
    sumList = list(reversed(reverse_sumList))
    actual_Sum = ""

    #Using Loop to converts obtained binary sum present in list to String by concatenation
    for j in range(len(sumList)):
        actual_Sum = actual_Sum+str(sumList[j])
    print("Binary sum of ",a," and ",b," is",actual_Sum)

    #Converting the binary sum to decimal by calling converter function from Conversion.py module
    sum_Of_Two_Numbers = binaryToDecimalConversion(actual_Sum)
    print()
    print("The sum of ",a," and ",b," is", sum_Of_Two_Numbers)

    choice = input("Enter Your Choice")
    print("Enter yes To continue")
    print("Enter no to Quit")

    while choice != "yes" and choice != "no":
        print()
        print("Enter the correct choice")
        print()
        print("Enter yes To continue")
        print("Enter no to Quit")
    if choice =="no":
        print("!!!!!!!!!THNAK YOU FOR USING !!!!!")
        print()
        print("---------------HAVE A GOOD DAY-------")
    print("-------------------------------------------------")
            
            
                
                      
            
            
                           


            

            
            

            

            
        
        
