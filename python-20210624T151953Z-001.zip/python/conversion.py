# converion dec to bin


def decimalToBinaryConversion(decimalValue):
    binaryValue="%08d" % int(bin(decimalValue)[2:])
    return binaryValue

# Converts a binary number to decimal
def binaryToDecimalConversion(binaryValue):
    decimalValue = int(binaryValue,2)
    return binaryValue

    
