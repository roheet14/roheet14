import gates

def adder(reverse_List_Of_Number_a,reverse_List_Of_Number_b):
    carry_in=0
    reverse_sumList=[]

    for i in range(len(reverse_List_Of_Number_a)):
        _xorOutput = _xorGate(int(reverse_List_Of_Number_a[i]),int(reverse_List_Of_Number_b[i]))
        and1 = andGate(int(reverse_List_Of_Number_a[i]),int(reverse_List_Of_Number_b[i]))
        and2 = andGate(xorOutput,carry_in)
        nor = norGate(and1,and2)
        carry_out = notGate(nor)

        nand = nandGate(_xorOutput,carry_in)
        or_output = orGate(_xorOutput,carry_in)
        and3 = andGate(nand,or_output)
        Sum = and3
        carry_in = carry_out
        reverse_sumList.append(Sum)

    return reverse_sumList

    

