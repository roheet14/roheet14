#Gates
#OR gate

def orGate (x,y):
    return x|y

#AND gate

def andGate (x,y):
    return x & y

#XOR gate

def _xorGate (x,y):
    return x^y
