def _input ():
    flag = False
    while (not flag):
        print("--------WELCOME TO BINARY AND DECIMAL CONVERSION SYSTEM------")
        print()
        print("-------***Press B or b For Binary System***--------")
        print("-------***Press D or d For Decimal System***--------")
    
        user = input("Press you Choice: ")
        if (user.lower() =="d"):
            while (not flag):
                x = input("Enter the first Decimal Number: ")
                y = input("Enter the Second Decimal Number: ")
    
                for i in [x,y]:
                    for j in i:
                        try:
                            if int(j) not in [1,0]:
                                print("!!!INVALID!!!--- No Special Characters Are Allowed------")
                                count -= 1
                                break
                        except:
                            print("!!!INVALID!!!--- No Special Characters Are Allowed------")
                            count -= 1
                            break

        elif (user.lower() == "b"):
            while not flag:
                x = input("Enter The First Binary Number: ")
                y = input("Enter The Second Binary Number: ")

                count = len (a) + len (b)
                for i in [x,y]:
                    for j in i:
                        try:
                            if int(j) not in [1,0]:
                                print("!!!INVALID!!!--- No Special Characters Are Allowed------")
                                count -= 1
                                break
                        except:
                            print("!!!INVALID!!!--- No Special Characters Are Allowed------")
                            count -= 1
                            break

        else:
            print("Enter the proper type of number for addition")
        
   

_input()
                        
                
            

                                
                
    
        
        
